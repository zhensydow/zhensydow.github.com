#!/bin/bash

make

numPages=$(pdfinfo misal.pdf | grep Pages | awk '{ print $2}')
finalPages=$(( ((numPages - 1) >> 2) + 1))
totalPages=$((finalPages * 4))

echo "Pages $numPages  ->  $finalPages"

pages=""
for i in $(seq 1 $finalPages) ; do
    k1=$(( ((i - 1) * 2) + 1 ))
    k2=$((totalPages - $k1 + 1))
    for j in $k2 $k1 $((k1 + 1)) $((k2 - 1)); do
        if [ $j -gt $numPages ] ; then
            pages=$(echo "$pages B1")
        else
            pages=$(echo "$pages A$j")
        fi
    done
done

echo $pages

tmpfile=$(mktemp --tmpdir pdftk.XXXXXXXX.pdf)
echo $tmpfile

pdftk A=misal.pdf B=blank.pdf cat $pages output $tmpfile

pdfnup --outfile final.pdf --nup 2x1 $tmpfile
